package com.example.r_social

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
