import 'package:flutter/material.dart';

cachedNetworkImage(mediaUrl) {
  return Text('cached network image');
}
