import 'package:flutter/material.dart';

class postscreen extends StatefulWidget {
  @override
  _postscreenState createState() => _postscreenState();
}

class _postscreenState extends State<postscreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
