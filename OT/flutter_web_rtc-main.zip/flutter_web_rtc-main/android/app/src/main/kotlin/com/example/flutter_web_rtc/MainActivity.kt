package com.example.flutter_web_rtc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
